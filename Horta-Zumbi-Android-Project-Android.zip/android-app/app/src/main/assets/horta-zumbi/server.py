#!/usr/bin/env python3
"""Horta Zumbi — servidor local (HTTP + relay multiplayer WebSocket), só biblioteca padrão.
Uso:  python server.py [porta]   (padrão 8000)
Depois abra http://SEU_IP:8000 em todos os aparelhos da mesma Wi-Fi.
"""
import sys, os, json, socket, struct, base64, hashlib, threading, random, string
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
ROOT = os.path.dirname(os.path.abspath(__file__))
MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

rooms = {}          # code -> {'host': WS, 'clients': {pid: WS}, 'next': int}
rooms_lock = threading.Lock()


class WS:
    def __init__(self, sock):
        self.sock = sock; self.lock = threading.Lock(); self.open = True
    def send(self, obj):
        data = json.dumps(obj, separators=(',', ':')).encode()
        n = len(data)
        if n < 126: hdr = struct.pack('!BB', 0x81, n)
        elif n < 65536: hdr = struct.pack('!BBH', 0x81, 126, n)
        else: hdr = struct.pack('!BBQ', 0x81, 127, n)
        try:
            with self.lock: self.sock.sendall(hdr + data)
        except OSError: self.open = False
    def recv(self):
        def rd(k):
            b = b''
            while len(b) < k:
                c = self.sock.recv(k - len(b))
                if not c: raise OSError('closed')
                b += c
            return b
        msg = b''
        while True:
            b1, b2 = rd(2); op = b1 & 0x0F; n = b2 & 0x7F
            if n == 126: n = struct.unpack('!H', rd(2))[0]
            elif n == 127: n = struct.unpack('!Q', rd(8))[0]
            mask = rd(4) if b2 & 0x80 else None
            pl = rd(n)
            if mask: pl = bytes(pl[i] ^ mask[i % 4] for i in range(n))
            if op == 8: raise OSError('close')
            if op == 9:  # ping -> pong
                with self.lock: self.sock.sendall(struct.pack('!BB', 0x8A, len(pl)) + pl)
                continue
            if op == 10: continue
            msg += pl
            if b1 & 0x80: return msg.decode('utf-8', 'replace')


def leave(ws):
    with rooms_lock:
        for code, r in list(rooms.items()):
            if r['host'] is ws:
                for c in r['clients'].values(): c.send({'t': 'host_left'})
                del rooms[code]
            else:
                for pid, c in list(r['clients'].items()):
                    if c is ws:
                        del r['clients'][pid]
                        r['host'].send({'t': 'leave', 'from': pid})


def handle_ws(ws):
    role = None; room = None; pid = None
    try:
        while True:
            m = json.loads(ws.recv())
            t = m.get('t')
            if t == 'host':
                with rooms_lock:
                    code = ''.join(random.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(4))
                    while code in rooms: code = ''.join(random.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(4))
                    rooms[code] = {'host': ws, 'clients': {}, 'next': 2}
                role = 'host'; room = code; ws.send({'t': 'hosted', 'room': code})
            elif t == 'join':
                code = str(m.get('room', '')).upper().strip()
                with rooms_lock:
                    r = rooms.get(code)
                    if not r: ws.send({'t': 'error', 'msg': 'Sala não encontrada'}); continue
                    if len(r['clients']) >= 9: ws.send({'t': 'error', 'msg': 'Sala cheia'}); continue
                    pid = r['next']; r['next'] += 1; r['clients'][pid] = ws
                role = 'client'; room = code
                ws.send({'t': 'joined', 'room': code, 'pid': pid})
                r['host'].send({'t': 'join', 'from': pid, 'cls': m.get('cls'), 'name': m.get('name')})
            elif role == 'host' and room in rooms:
                to = m.pop('to', 'all'); r = rooms[room]
                if to == 'all':
                    for c in list(r['clients'].values()): c.send(m)
                else:
                    c = r['clients'].get(int(to))
                    if c: c.send(m)
            elif role == 'client' and room in rooms:
                m['from'] = pid; rooms[room]['host'].send(m)
    except Exception:
        pass
    finally:
        leave(ws)
        try: ws.sock.close()
        except OSError: pass


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def log_message(self, *a): pass
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); super().end_headers()
    def do_GET(self):
        if self.headers.get('Upgrade', '').lower() == 'websocket':
            key = self.headers.get('Sec-WebSocket-Key', '')
            acc = base64.b64encode(hashlib.sha1((key + MAGIC).encode()).digest()).decode()
            self.send_response(101); self.send_header('Upgrade', 'websocket'); self.send_header('Connection', 'Upgrade')
            self.send_header('Sec-WebSocket-Accept', acc); self.end_headers()
            self.close_connection = True
            sock = self.connection; sock.settimeout(None)
            self.wfile.flush()
            handle_ws(WS(sock))
            return
        super().do_GET()


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('10.255.255.255', 1)); ip = s.getsockname()[0]; s.close(); return ip
    except OSError: return '127.0.0.1'


if __name__ == '__main__':
    srv = ThreadingHTTPServer(('0.0.0.0', PORT), Handler); srv.daemon_threads = True
    print(f'🧟 Horta Zumbi rodando!\n  Neste PC:      http://localhost:{PORT}\n  Na mesma Wi-Fi: http://{lan_ip()}:{PORT}\n(Ctrl+C para parar)')
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
