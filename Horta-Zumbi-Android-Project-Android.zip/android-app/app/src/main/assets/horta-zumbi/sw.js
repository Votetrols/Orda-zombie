// Cache offline (PWA): depois de abrir uma vez com internet/na rede, o jogo funciona sem conexão.
const C='hz-v17';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))))});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||e.request.url.includes('/ws'))return;
  e.respondWith(caches.open(C).then(async c=>{const r=await c.match(e.request,{ignoreSearch:true});const f=fetch(e.request).then(res=>{if(res.ok)c.put(e.request,res.clone());return res}).catch(()=>r);return r||f}))});
