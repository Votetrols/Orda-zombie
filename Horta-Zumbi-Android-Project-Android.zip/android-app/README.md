# Horta Zumbi — Projeto Android

Projeto Android que empacota o jogo HTML original em um WebView otimizado para celular.

## Adaptações Android

- Tela cheia/imersiva em orientação paisagem.
- Mantém a tela ligada durante a partida.
- WebView sem zoom, barras ou overscroll acidental.
- JavaScript, DOM Storage e áudio habilitados.
- Arquivos do jogo são carregados de dentro do APK por `WebViewAssetLoader`.
- Permissão de câmera preparada para leitura de QR Code/WebRTC.
- Botão **Voltar**: fecha modal aberto, depois abre o menu de pausa; só sai após dois toques quando não há menu.
- Salvamento do jogo continua usando `localStorage`.
- Não executa `server.py`; o multiplayer WebRTC/P2P pode funcionar sem servidor quando suportado pelo jogo.

## Abrir no Android Studio

1. Extraia este projeto.
2. Abra a pasta `android-app` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Execute em um aparelho Android em modo paisagem ou use **Build > Build APK(s)**.

APK de debug:

`app/build/outputs/apk/debug/app-debug.apk`

## Observação sobre o multiplayer

O jogo original possui dois caminhos de rede: WebSocket para o servidor e WebRTC/P2P para conexão direta. O APK não inicia automaticamente o `server.py`, portanto recursos que dependem de um servidor WebSocket continuam dependendo de um servidor externo.
